# Asset Manifest

최종 사이트에서 실제로 사용하는 이미지와 위치입니다.

| Page | Asset |
|---|---|
| `tools/avogadro.html` | `avogadro/avg-b01-img01-main-ui.png` |
| `tools/avogadro.html` | `avogadro/avg-b02-img01-build-hydrogens-menu.png` |
| `tools/avogadro.html` | `avogadro/avg-b03-img02-force-field-settings.png` |
| `tools/avogadro.html` | `avogadro/avg-b04-img02-measure-result-closeup.png` |
| `tools/avogadro.html` | `avogadro/avg-b05-img02-save-as-dialog.png` |
| `tools/avogadro.html` | `avogadro/avg-b06-img01-orca-menu.png` |
| `tools/avogadro.html` | `avogadro/avg-b06-img02-orca-input-generator.png` |
| `tools/orca.html` | `orca/orc-b01-img01-run-command.png` |
| `tools/orca.html` | `orca/orc-b01-img03-normal-termination.png` |
| `tools/orca.html` | `orca/orc-b02-img01-final-single-point-energy.png` |
| `tools/orca.html` | `orca/orc-b02-img02-optimization-converged.png` |
| `tools/orca.html` | `orca/orc-b03-img01-vibrational-frequencies.png` |
| `tools/orca.html` | `orca/orc-b04-img01-orbital-energies.png` |
| `tools/orca.html` | `orca/orc-b04-img02-mulliken-charges.png` |
| `tools/orca.html` | `orca/orc-b04-img03-loewdin-charges.png` |
| `tools/pymol.html` | `pymol/pym-b02-img01-cartoon-and-sticks.png` |
| `tools/pymol.html` | `pymol/pym-b03-img01-pocket-selection.png` |
| `tools/pymol.html` | `pymol/pym-b04-img01-get-distance-result.png` |
| `tools/vina.html` | `vina/vna-b01-img01-autodocktools-main-ui.png` |
| `tools/vina.html` | `vina/vna-b02-img14-choose-torsions.png` |
| `tools/vina.html` | `vina/vna-b02-img15-save-ligand-pdbqt.png` |
| `tools/vina.html` | `vina/vna-b03-img03-add-hydrogens-dialog.png` |
| `tools/vina.html` | `vina/vna-b03-img06-integral-residue-charges.png` |
| `tools/vina.html` | `vina/vna-b03-img08-save-receptor-pdbqt.png` |
| `tools/vina.html` | `vina/vna-b03-warn03-nonintegral-residue-charges.png` |
| `tools/vina.html` | `vina/vna-b04-img01-active-site-grid-box.png` |
| `tools/vina.html` | `vina/vna-b05-img01-vina-run-and-results.png` |
